#!/usr/bin/env python3
"""
IK ONKAR - THE LIGHT OF ONE   (Guru Nanak Jayanti cinematic reel, pure Python)

Renders a 1080x1920 (9:16), 30 fps, ~54 second film + procedural score
straight to an Instagram-ready MP4 (H.264 + AAC).

    pip install numpy pillow imageio-ffmpeg
    python ik_onkar_cinematic.py                 # full quality render
    python ik_onkar_cinematic.py --fast          # 540x960 quick preview
    python ik_onkar_cinematic.py --still 25      # save one frame (t = 25 s) as PNG

Assets (put in ./assets):
    guru.jpeg      portrait artwork (Guru Nanak Dev Ji)
    village.jpeg   night village / gurdwara artwork
    fonts/*.ttf    optional: any Gurmukhi font (e.g. NotoSansGurmukhi-Bold.ttf)
                   Windows (Nirmala UI) and macOS (Gurmukhi MN) are auto-detected.
"""
from __future__ import annotations

import argparse
import math
import os
import shutil
import subprocess
import sys
import time
import wave

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 1080, 1920
W2, H2 = W // 2, H // 2          # half-res buffer used for all glow work
FPS = 30
DUR = 54.0
HERE = os.path.dirname(os.path.abspath(__file__))
GOLD = np.array([1.0, 0.80, 0.42], np.float32)
WARM = np.array([1.0, 0.62, 0.22], np.float32)
ICE = np.array([0.55, 0.75, 1.0], np.float32)


# ----------------------------------------------------------------- math ---
def clamp(x, a=0.0, b=1.0):
    return min(b, max(a, x))


def ss(a, b, x):
    u = clamp((x - a) / (b - a))
    return u * u * (3 - 2 * u)


def lerp(a, b, u):
    return a + (b - a) * u


def win(t, a, b, fi=1.0, fo=1.0):
    return ss(a, a + fi, t) * (1 - ss(b - fo, b, t))


def ssa(a, b, x):
    u = np.clip((x - a) / (b - a), 0, 1)
    return u * u * (3 - 2 * u)


# ---------------------------------------------------------------- fonts ---
def _first_existing(paths):
    for p in paths:
        if os.path.exists(p):
            return p
    return None


LAT_ITALIC = _first_existing([
    "C:/Windows/Fonts/georgiai.ttf", "/System/Library/Fonts/Supplemental/Georgia Italic.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf"])
LAT_BOLD = _first_existing([
    "C:/Windows/Fonts/georgiab.ttf", "/System/Library/Fonts/Supplemental/Georgia Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"])

_GUR_CANDIDATES = (
    [os.path.join(HERE, "assets", "fonts", f) for f in
     (sorted(os.listdir(os.path.join(HERE, "assets", "fonts")))
      if os.path.isdir(os.path.join(HERE, "assets", "fonts")) else [])
     if f.lower().endswith((".ttf", ".otf", ".ttc"))]
    + ["C:/Windows/Fonts/NirmalaB.ttf", "C:/Windows/Fonts/Nirmala.ttf",
       "/System/Library/Fonts/Supplemental/Gurmukhi MN.ttc",
       "/usr/share/fonts/truetype/noto/NotoSansGurmukhi-Bold.ttf",
       "/usr/share/fonts/truetype/noto/NotoSansGurmukhi-Regular.ttf",
       "/usr/share/fonts/truetype/lohit-gurmukhi/Lohit-Gurmukhi.ttf"])


def _font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def _supports_onkar(fpath):
    """True if the font really has the glyph U+0A74 (not just a .notdef box)."""
    try:
        f = ImageFont.truetype(fpath, 120)
        a = f.getmask("\u0a74")
        b = f.getmask("\U0010FFFF")
        return a.getbbox() is not None and (a.size != b.size or bytes(a) != bytes(b))
    except Exception:
        return False


GUR_FONT = next((p for p in _GUR_CANDIDATES if p and os.path.exists(p) and _supports_onkar(p)), None)


# ---------------------------------------------------------------- glyph ---
def _bez(p0, p1, p2, p3, n=70):
    out = []
    for i in range(n + 1):
        u = i / n
        v = 1 - u
        out.append((v**3 * p0[0] + 3 * v * v * u * p1[0] + 3 * v * u * u * p2[0] + u**3 * p3[0],
                    v**3 * p0[1] + 3 * v * v * u * p1[1] + 3 * v * u * u * p2[1] + u**3 * p3[1]))
    return out


def _fallback_glyph():
    """Hand-drawn approximation of the Ik Onkar, used only if no Gurmukhi font is found."""
    S = 900
    im = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(im)
    pts = _bez((300, 230), (340, 330), (340, 560), (300, 720)) + _bez((300, 230), (250, 250), (200, 300), (190, 370))
    for a in np.linspace(math.radians(200), math.radians(500), 140):
        pts.append((585 + 175 * math.cos(a), 560 + 195 * math.sin(a)))
    pts += _bez((470, 330), (560, 240), (720, 240), (800, 170))
    for x, y in pts:
        d.ellipse((x - 24, y - 24, x + 24, y + 24), fill=255)
    return im


def glyph_mask():
    if GUR_FONT:
        f = ImageFont.truetype(GUR_FONT, 760)
        im = Image.new("L", (1100, 1100), 0)
        ImageDraw.Draw(im).text((550, 550), "\u0a74", font=f, fill=255, anchor="mm")
    else:
        print("[!] No Gurmukhi font found -> using hand-drawn fallback glyph. "
              "Drop a Gurmukhi .ttf in assets/fonts/ for the real thing.")
        im = _fallback_glyph()
    bb = im.getbbox()
    return im.crop(bb)


# ----------------------------------------------------------------- text ---
_SPRITES = {}


def text_sprite(text, size, kind="italic", core=(1.0, 0.9, 0.68), glow=(1.0, 0.62, 0.2)):
    key = (text, size, kind)
    if key in _SPRITES:
        return _SPRITES[key]
    path = {"italic": LAT_ITALIC, "bold": LAT_BOLD, "gur": GUR_FONT}[kind]
    f = _font(path, size)
    lines = text.split("\n")
    lh = int(size * 1.35)
    pad = 90
    w = int(max(f.getlength(l) for l in lines)) + pad * 2
    h = lh * len(lines) + pad * 2
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    for i, l in enumerate(lines):
        d.text((w / 2, pad + lh * i + lh / 2), l, font=f, fill=255, anchor="mm")
    mm = np.asarray(m, np.float32) / 255
    g1 = np.asarray(m.filter(ImageFilter.GaussianBlur(10)), np.float32) / 255
    g2 = np.asarray(m.filter(ImageFilter.GaussianBlur(32)), np.float32) / 255
    spr = (mm[..., None] * np.array(core, np.float32)
           + (g1[..., None] * 0.9 + g2[..., None] * 1.3) * np.array(glow, np.float32) * 0.8)
    spr = np.clip(spr, 0, 1).astype(np.float32)
    _SPRITES[key] = spr
    return spr


def blit_add(frame, spr, cx, cy, alpha):
    if alpha <= 0.002:
        return
    h, w = spr.shape[:2]
    x0, y0 = int(cx - w / 2), int(cy - h / 2)
    sx0, sy0 = max(0, -x0), max(0, -y0)
    x1, y1 = min(W, x0 + w), min(H, y0 + h)
    if x1 <= x0 or y1 <= y0:
        return
    frame[y0 + sy0:y1, x0 + sx0:x1] += spr[sy0:sy0 + (y1 - y0 - sy0), sx0:sx0 + (x1 - x0 - sx0)] * alpha


# schedule: (start, end, text, size, kind, cy, sub-delay)
TEXTS = [
    (2.0, 6.6, "Jab chaaron taraf andhera tha...", 62, "italic", 1380),
    (7.6, 11.8, "Ek Onkar", 124, "bold", 1330),
    (8.3, 11.8, "Ek hi Noor.  Ek hi Rab.", 50, "italic", 1450),
    (11.9, 16.6, "Ek chhote se gaon ki\nshaant raat mein...", 64, "italic", 1400),
    (17.0, 22.0, "Ek roshni ne janam liya \u2014\njo poori duniya ka andhera\nmitaane aayi thi.", 62, "italic", 1380),
    (25.2, 31.6, "Guru Nanak Dev Ji", 104, "bold", 1500),
    (31.9, 36.2, "\u201cNa koi Hindu, na Musalman\u201d\nsab ek hi noor ke bande.", 58, "italic", 1500),
    (36.8, 39.9, "Naam Japo", 100, "bold", 1470),
    (37.3, 39.9, "Rab ko har pal yaad karo", 46, "italic", 1590),
    (39.9, 42.9, "Kirat Karo", 100, "bold", 1470),
    (40.4, 42.9, "Imaandari se mehnat karo", 46, "italic", 1590),
    (42.9, 46.3, "Vand Chakko", 100, "bold", 1470),
    (43.4, 46.3, "Mil baant kar khao", 46, "italic", 1590),
    (47.8, 53.7, "Guru Nanak Jayanti ki\nlakh lakh vadhaiyan", 72, "italic", 1260),
    (49.4, 53.7, "Waheguru Ji", 58, "bold", 1440),
]
GUR_TEXTS = [  # only drawn when a Gurmukhi font is available
    (25.6, 31.6, "\u0a17\u0a41\u0a30\u0a42 \u0a28\u0a3e\u0a28\u0a15 \u0a26\u0a47\u0a35 \u0a1c\u0a40", 60, 1610),
    (36.8, 39.9, "\u0a28\u0a3e\u0a2e \u0a1c\u0a2a\u0a4b", 54, 1370),
    (39.9, 42.9, "\u0a15\u0a3f\u0a30\u0a24 \u0a15\u0a30\u0a4b", 54, 1370),
    (42.9, 46.3, "\u0a35\u0a70\u0a21 \u0a1b\u0a15\u0a4b", 54, 1370),
    (49.4, 53.7, "\u0a35\u0a3e\u0a39\u0a3f\u0a17\u0a41\u0a30\u0a42", 64, 1540),
]


# -------------------------------------------------------------- imagery ---
def load_art(path, crop, k=1.2):
    im = Image.open(path).convert("RGB")
    w, h = im.size
    im = im.crop((int(crop[0] * w), int(crop[1] * h), int(crop[2] * w), int(crop[3] * h)))
    tw, th = int(W * k), int(H * k)
    s = max(tw / im.width, th / im.height)
    im = im.resize((math.ceil(im.width * s), math.ceil(im.height * s)), Image.LANCZOS)
    l, t = (im.width - tw) // 2, (im.height - th) // 2
    im = im.crop((l, t, l + tw, t + th))
    return im.filter(ImageFilter.UnsharpMask(radius=2.2, percent=70, threshold=2))


def kb(im, u, f0, f1, c0, c1):
    """Ken-Burns camera. Returns (float frame, (x0,y0,bw,bh) of the view in big-image px)."""
    f = lerp(f0, f1, u)
    cx, cy = lerp(c0[0], c1[0], u), lerp(c0[1], c1[1], u)
    bw, bh = im.width * f, im.height * f
    x0 = clamp(cx * im.width - bw / 2, 0, im.width - bw)
    y0 = clamp(cy * im.height - bh / 2, 0, im.height - bh)
    out = im.resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + bw, y0 + bh))
    return np.asarray(out, np.float32) / 255, (x0, y0, bw, bh)


def to_screen(box, im, fx, fy):
    x0, y0, bw, bh = box
    return ((fx * im.width - x0) / bw * W, (fy * im.height - y0) / bh * H)


def sprite_glow(r):
    y, x = np.mgrid[-r:r, -r:r].astype(np.float32)
    d = np.hypot(x, y) / r
    return np.clip(1 - d, 0, 1) ** 2.2


def add_sprite(A, spr, cx, cy, color, gain):
    if gain <= 0.002:
        return
    r = spr.shape[0] // 2
    x0, y0 = int(cx / 2 - r), int(cy / 2 - r)
    sx0, sy0 = max(0, -x0), max(0, -y0)
    x1, y1 = min(W2, x0 + 2 * r), min(H2, y0 + 2 * r)
    if x1 <= x0 or y1 <= y0:
        return
    s = spr[sy0:sy0 + (y1 - y0 - sy0), sx0:sx0 + (x1 - x0 - sx0)]
    A[y0 + sy0:y1, x0 + sx0:x1] += s[..., None] * color * gain


def splat(xs, ys, w):
    buf = np.zeros((H2, W2), np.float32)
    ix, iy = (xs * 0.5).astype(np.int32), (ys * 0.5).astype(np.int32)
    m = (ix >= 0) & (ix < W2) & (iy >= 0) & (iy < H2)
    np.add.at(buf, (iy[m], ix[m]), w[m])
    return buf


def bloom(buf):
    im = Image.fromarray((np.clip(buf, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(3))
    a = np.asarray(im.filter(ImageFilter.GaussianBlur(1.2)), np.float32) / 255
    b = np.asarray(im.filter(ImageFilter.GaussianBlur(6)), np.float32) / 255
    c = np.asarray(im.filter(ImageFilter.GaussianBlur(20)), np.float32) / 255
    return a * 1.0 + b * 3.2 + c * 6.0


# ------------------------------------------------------------- the film ---
class Film:
    def __init__(self, guru_path, village_path):
        rng = np.random.default_rng(11)
        self.rng = rng
        # cosmos background gradient
        yy = np.linspace(0, 1, H, dtype=np.float32)[:, None]
        stops = [(0.0, (2, 4, 13)), (0.5, (7, 21, 53)), (1.0, (12, 34, 74))]
        cols = np.zeros((H, 3), np.float32)
        for i in range(3):
            cols[:, i] = np.interp(yy[:, 0], [s[0] for s in stops], [s[1][i] for s in stops]) / 255
        self.cosmos = np.repeat(cols[:, None, :], W, axis=1)
        # stars / dust
        self.sx, self.sy = rng.random(420) * W, rng.random(420) * H
        self.sr, self.sp, self.ss_ = rng.random(420) * 1.6 + 0.4, rng.random(420) * 6.28, rng.random(420) * 2 + 0.5
        self.dx, self.dy = rng.random(160) * W, rng.random(160) * H
        self.dv, self.dp = rng.random(160) * 22 + 8, rng.random(160) * 6.28
        # glyph particles
        gm = glyph_mask()
        self.glyph_img = gm
        gw = 560
        gh = int(gm.height * gw / gm.width)
        if gh > 760:
            gh, gw = 760, int(gm.width * 760 / gm.height)
        gms = gm.resize((gw, gh), Image.LANCZOS)
        self.glyph_arr = np.asarray(gms, np.float32) / 255
        self.gsize = (gw, gh)
        ys, xs = np.nonzero(self.glyph_arr > 0.5)
        n = 3400
        idx = rng.integers(0, len(xs), n)
        self.gcx, self.gcy = 540, 800
        self.tx = xs[idx] - gw / 2 + self.gcx + rng.normal(0, 1.2, n)
        self.ty = ys[idx] - gh / 2 + self.gcy + rng.normal(0, 1.2, n)
        ang = rng.random(n) * 6.283
        dist = 420 + rng.random(n) ** 0.6 * 900
        self.px0 = 540 + np.cos(ang) * dist
        self.py0 = 800 + np.sin(ang) * dist * 1.25
        self.pdelay = rng.random(n)
        self.pph = rng.random(n) * 6.28
        self.pb = rng.random(n) * 0.6 + 0.4
        pad = 120
        padded = np.zeros((gh + pad * 2, gw + pad * 2), np.float32)
        padded[pad:pad + gh, pad:pad + gw] = self.glyph_arr
        gblur = np.asarray(Image.fromarray((padded * 255).astype(np.uint8))
                           .filter(ImageFilter.GaussianBlur(26)), np.float32) / 255
        spr = gblur[..., None] * np.array([1.0, 0.6, 0.2], np.float32) * 1.1
        spr += padded[..., None] * np.array([1.0, 0.86, 0.5], np.float32)
        self.glyph_sprite = np.clip(spr, 0, 1)
        # rising golden motes (guru scene) + fireflies (village)
        self.rx, self.ry = rng.random(520) * W, rng.random(520) * H
        self.rv, self.rph = rng.random(520) * 70 + 25, rng.random(520) * 6.28
        self.fx, self.fy = rng.random(46) * W, 1000 + rng.random(46) * 800
        self.fph = rng.random(46) * 6.28
        self.gl_x, self.gl_y, self.gl_p = rng.random(180) * W, rng.random(180) * H, rng.random(180) * 6.28
        # images
        self.guru = load_art(guru_path, (0.025, 0.060, 0.975, 0.800))
        self.village = load_art(village_path, (0.025, 0.060, 0.975, 0.790))
        # grids / sprites
        gy, gx = np.mgrid[0:H2, 0:W2].astype(np.float32)
        self.GX, self.GY = gx, gy
        self.halo_big = sprite_glow(360)
        self.halo_mid = sprite_glow(170)
        self.blob = sprite_glow(300)
        yv = np.linspace(0, 1, H, dtype=np.float32)
        self.shade = (np.clip((yv - 0.42) / 0.5, 0, 1) ** 1.4 * 0.88)[:, None, None]
        yy2, xx2 = np.mgrid[0:H, 0:W].astype(np.float32)
        r2 = ((xx2 - W / 2) / (W * 0.75)) ** 2 + ((yy2 - H / 2) / (H * 0.7)) ** 2
        self.vig = (1 - 0.62 * np.clip(r2, 0, 1) ** 1.2)[..., None].astype(np.float32)
        self.grain = [(rng.normal(0, 1, (H, W)) * 0.022).astype(np.float32)[..., None] for _ in range(5)]

    # ---- helpers
    def rays(self, sx, sy, t, strength):
        dx, dy = self.GX - sx / 2, self.GY - sy / 2
        ang, d = np.arctan2(dy, dx), np.hypot(dx, dy)
        pat = (0.5 + 0.5 * np.sin(ang * 9 + t * 0.35)) * (0.5 + 0.5 * np.sin(ang * 23 - t * 0.5 + 1.3))
        pat = pat ** 1.7
        return (pat * np.exp(-d / 330) * 0.9 + np.exp(-(d / 70) ** 2) * 1.2) * strength

    def glyph_progress(self, t):
        return ss(1.0, 7.2, t) * (1 - ss(9.6, 12.2, t)) + ss(46.4, 51.8, t)

    # ---- one frame
    def render(self, t):
        rng_frame = int(t * FPS)
        aV = win(t, 10.0, 24.2, 2.8, 1.9)
        aG = win(t, 22.3, 47.4, 0.5, 2.8)
        wc = 1 - max(aV, aG)
        frame = self.cosmos.copy()
        A = np.zeros((H2, W2, 3), np.float32)

        # ---- cosmos: nebula, stars, dust
        if wc > 0.01:
            for i, (bx, by, col, g) in enumerate([(300, 650, ICE, 0.16), (800, 1250, WARM, 0.13), (560, 300, GOLD, 0.10)]):
                add_sprite(A, self.blob, bx + 80 * math.sin(t * 0.07 + i * 2), by + 60 * math.cos(t * 0.05 + i), col, g * wc)
            x = (self.sx + t * self.ss_ * 3) % W
            tw = 0.55 + 0.45 * np.sin(t * self.ss_ + self.sp)
            iy, ix = np.clip(self.sy.astype(int), 0, H - 1), np.clip(x.astype(int), 0, W - 1)
            frame[iy, ix] += (tw * (self.sr / 2.0) * wc)[:, None] * np.array([0.9, 0.95, 1.0], np.float32)
            big = self.sr > 1.35
            frame[np.clip(iy[big] + 1, 0, H - 1), ix[big]] += (tw[big] * 0.4 * wc)[:, None]
            A += bloom(splat(x[big], self.sy[big], tw[big] * 0.5 * wc))[..., None] * 0.35 * np.array([0.8, 0.9, 1], np.float32)
        # golden dust (always)
        ddy = (self.dy - t * self.dv) % H
        ddx = self.dx + np.sin(t * 0.4 + self.dp) * 26
        A += bloom(splat(ddx, ddy, (0.35 + 0.25 * np.sin(t * 1.3 + self.dp)) * 0.55))[..., None] * GOLD * 0.30

        # ---- glyph particles
        p = self.glyph_progress(t)
        if p > 0.003:
            lp = np.clip((p - self.pdelay * 0.55) / 0.45, 0, 1)
            e = lp * lp * (3 - 2 * lp)
            swirl = (1 - e) * 1.6
            ca, sa_ = np.cos(swirl), np.sin(swirl)
            rx, ry = self.px0 - self.gcx, self.py0 - self.gcy
            sx = self.gcx + rx * ca - ry * sa_
            sy = self.gcy + rx * sa_ + ry * ca
            px = lerp(sx, self.tx, e) + np.sin(t * 1.3 + self.pph) * (2 + 22 * (1 - e))
            py = lerp(sy, self.ty, e) + np.cos(t * 1.1 + self.pph) * (2 + 22 * (1 - e))
            br = self.pb * (0.6 + 0.4 * np.sin(t * 2.2 + self.pph)) * np.clip(p * 3, 0, 1)
            A += bloom(splat(px, py, br * 0.9))[..., None] * GOLD * 0.6
            solid = ss(0.82, 1.0, p) * (0.82 + 0.12 * math.sin(t * 1.6))
            gs = self.glyph_sprite
            blit_add(frame, gs, self.gcx, self.gcy, solid * 0.9)
            add_sprite(A, self.halo_big, self.gcx, self.gcy, WARM, 0.55 * solid)

        # ---- village
        if aV > 0.003:
            u = clamp((t - 9.5) / 14.5)
            v, box = kb(self.village, u, 0.98, 0.78, (0.5, 0.52), (0.44, 0.42))
            v = v * (0.92 + 0.08 * math.sin(t * 0.7))
            frame = frame * (1 - aV) + v * aV
            # fireflies
            fxx = (self.fx + np.sin(t * 0.5 + self.fph) * 70 + t * 4) % W
            fyy = self.fy + np.cos(t * 0.4 + self.fph * 1.7) * 50
            fw = np.clip(np.sin(t * 2.2 + self.fph * 3), 0, 1) ** 2
            A += bloom(splat(fxx, fyy, fw * 1.2 * aV))[..., None] * np.array([1.0, 0.95, 0.5], np.float32) * 0.9
            # moon bloom + shooting star
            mx, my = to_screen(box, self.village, 0.68, 0.125)
            add_sprite(A, self.halo_mid, mx, my, np.array([0.8, 0.88, 1.0], np.float32), 0.35 * aV)
            tt = (t - 13.4) / 1.1
            if 0 <= tt <= 1:
                k = np.linspace(0, 1, 60)
                hx, hy = lerp(980, 380, tt), lerp(120, 470, tt)
                A += bloom(splat(hx + (k * 260), hy - (k * 120), (1 - k) * 1.6 * math.sin(math.pi * tt)))[..., None] * 0.9
            # anticipation rays
            ray_s = ss(18.8, 22.5, t) * aV
            if ray_s > 0.01:
                A += self.rays(mx, my, t, ray_s * 0.55)[..., None] * GOLD
                add_sprite(A, self.halo_big, mx, my, GOLD, ray_s * 0.9)

        # ---- guru reveal
        if aG > 0.003:
            u = clamp((t - 22.3) / 24.5)
            g, gbox = kb(self.guru, u, 0.97, 0.70, (0.5, 0.46), (0.52, 0.34))
            g = g * (1 - 0.48 * win(t, 35.8, 47.4, 1.4, 0.1))
            frame = frame * (1 - aG) + g * aG
            mx, my = to_screen(gbox, self.guru, 0.486, 0.147)
            pulse = 0.75 + 0.25 * math.sin(t * 1.2)
            A += self.rays(mx, my, t, aG * 0.62 * pulse)[..., None] * GOLD
            add_sprite(A, self.halo_big, mx, my, GOLD, aG * 0.8 * pulse)
            # rising motes
            ry = (self.ry - t * self.rv) % H
            rx = self.rx + np.sin(t * 0.6 + self.rph) * 34
            rw = (0.5 + 0.5 * np.sin(t * 1.8 + self.rph)) * aG
            A += bloom(splat(rx, ry, rw * 0.9))[..., None] * GOLD * 0.8
            # glitter
            gw_ = np.clip(np.sin(t * 3.1 + self.gl_p * 5), 0, 1) ** 8 * aG
            A += bloom(splat(self.gl_x, self.gl_y, gw_ * 1.4))[..., None] * np.array([1, 0.95, 0.8], np.float32) * 0.9

        # ---- light-up, bottom shade for legibility
        sa = 0.30 * aV + 0.75 * aG
        frame *= (1 - self.shade * sa)

        # ---- upsample glow & composite
        a_up = Image.fromarray((np.clip(A, 0, 1) * 255).astype(np.uint8)).resize((W, H), Image.BILINEAR)
        frame += np.asarray(a_up, np.float32) / 255

        # ---- the flash at the reveal
        if t < 22.5:
            fl = ss(21.4, 22.5, t) * 0.9
        else:
            fl = 0.9 * math.exp(-(t - 22.5) * 3.0)
        if fl > 0.004:
            frame += fl * np.array([1.0, 0.92, 0.75], np.float32)

        # ---- text
        for a, b, txt, size, kind, cy in TEXTS:
            al = win(t, a, b, 1.1, 0.9)
            if al > 0.003:
                drift = (1 - ss(a, a + 1.4, t)) * 22
                blit_add(frame, text_sprite(txt, size, kind), W / 2, cy + drift, al)
        if GUR_FONT:
            for a, b, txt, size, cy in GUR_TEXTS:
                al = win(t, a, b, 1.1, 0.9)
                if al > 0.003:
                    blit_add(frame, text_sprite(txt, size, "gur"), W / 2, cy + (1 - ss(a, a + 1.4, t)) * 22, al)

        # ---- grade: vignette, grain, global fades
        frame *= self.vig
        frame += self.grain[rng_frame % 5]
        frame *= ss(0.0, 1.8, t) * (1 - ss(DUR - 1.4, DUR, t))
        return (np.clip(frame, 0, 1) * 255).astype(np.uint8)


# ---------------------------------------------------------------- audio ---
def synth_audio(path):
    sr = 44100
    n = int(DUR * sr)
    t = (np.arange(n) / sr).astype(np.float64)
    rng = np.random.default_rng(5)
    swell = ssa(20.5, 23.5, t) * (1 - ssa(36, 40, t)) + ssa(46, 50, t) + 0.35 * ssa(7, 10, t) * (1 - ssa(12, 16, t))
    master = ssa(0, 5, t) * (1 - ssa(DUR - 3.5, DUR, t))
    L = np.zeros(n)
    R = np.zeros(n)

    # drone (Sa = D)
    for f, g in ((73.42, 1.0), (110.0, 0.55), (146.83, 0.45), (220.0, 0.16)):
        for det, ch in ((-0.5, 0), (0.0, 2), (0.5, 1)):
            ff = f * (1 + det / 100)
            for h, hg in ((1, 1), (2, .5), (3, .28), (4, .16), (5, .09)):
                s = g * hg * np.sin(2 * np.pi * ff * h * t + det * 3)
                if ch in (0, 2):
                    L += s * 0.020
                if ch in (1, 2):
                    R += s * 0.020
    trem = 0.86 + 0.14 * np.sin(2 * np.pi * 0.07 * t)
    L *= trem * (0.55 + 0.5 * swell)
    R *= trem * (0.55 + 0.5 * swell)

    # warm pad chord D - A - E - A(high)
    for f in (293.66, 440.0, 659.25, 880.0):
        for det, tgt in ((-0.004, "L"), (0.004, "R")):
            s = np.sin(2 * np.pi * f * (1 + det) * t) * 0.5 + np.sin(2 * np.pi * f * 2 * (1 + det) * t) * 0.12
            s *= 0.5 + 0.5 * np.sin(2 * np.pi * 0.09 * t + f)
            if tgt == "L":
                L += s * swell * 0.030
            else:
                R += s * swell * 0.030

    # tanpura (Pa Sa Sa Sa)
    notes = [110.0, 146.83, 146.83, 73.42]
    k, tp = 0, 2.0
    while tp < DUR - 2:
        f = notes[k % 4]
        i0 = int(tp * sr)
        m = min(int(5 * sr), n - i0)
        tau = np.arange(m) / sr
        e = np.exp(-tau * 1.0) * (1 - np.exp(-tau * 90))
        s = np.zeros(m)
        for h in range(1, 11):
            s += np.sin(2 * np.pi * f * h * tau) * (1.0 / h ** 0.8) * (1.4 if h in (4, 5, 6) else 1.0) * np.exp(-tau * 0.25 * h)
        pan = 0.35 if k % 2 else 0.65
        L[i0:i0 + m] += s * e * 0.055 * (1 - pan)
        R[i0:i0 + m] += s * e * 0.055 * pan
        k += 1
        tp += 0.92

    def bell(t0, f, gain, pan=0.5, dec=0.8):
        i0 = int(t0 * sr)
        m = min(int(8 * sr), n - i0)
        if m <= 0:
            return
        tau = np.arange(m) / sr
        s = np.zeros(m)
        for j, (mult, amp) in enumerate(((1, 1.0), (2.0, .45), (2.76, .5), (4.1, .2), (5.4, .22), (8.93, .08))):
            s += amp * np.sin(2 * np.pi * f * mult * tau) * np.exp(-tau * (dec + 0.55 * j))
        s *= (1 - np.exp(-tau * 600)) * gain
        L[i0:i0 + m] += s * (1 - pan)
        R[i0:i0 + m] += s * pan

    for t0, f, g, p in ((7.6, 587.33, 0.05, .5), (8.2, 880.0, 0.03, .6), (24.0, 587.33, 0.06, .4), (25.2, 880.0, 0.05, .6),
                        (28.5, 659.25, 0.035, .35), (31.9, 880.0, 0.04, .65), (36.8, 587.33, 0.06, .4),
                        (39.9, 659.25, 0.06, .55), (42.9, 880.0, 0.06, .45), (47.9, 587.33, 0.06, .5),
                        (49.4, 880.0, 0.05, .4), (51.0, 1174.66, 0.04, .6)):
        bell(t0, f, g, p, 0.6)

    # riser + boom at the reveal
    i0 = int(18.0 * sr)
    m = int(9 * sr)
    noise = rng.normal(0, 1, m)
    spec = np.fft.rfft(noise)
    fr = np.fft.rfftfreq(m, 1 / sr)
    spec *= ((fr > 700) & (fr < 7000)) * (1 / (1 + fr / 2500))
    nz = np.fft.irfft(spec, m)
    nz /= np.max(np.abs(nz))
    tt = np.arange(m) / sr + 18.0
    env = ssa(18.0, 22.5, tt) ** 2.2 * (1 - ssa(22.5, 25.0, tt))
    L[i0:i0 + m] += nz * env * 0.12
    R[i0:i0 + m] += np.roll(nz, 400) * env * 0.12
    i1 = int(22.45 * sr)
    m2 = int(7 * sr)
    tau = np.arange(m2) / sr
    ph = 2 * np.pi * np.cumsum(38 + 40 * np.exp(-tau * 3.5)) / sr
    boom = np.sin(ph) * np.exp(-tau * 0.9) * (1 - np.exp(-tau * 120)) * 0.55
    L[i1:i1 + m2] += boom
    R[i1:i1 + m2] += boom

    # reverb (stereo synthetic hall)
    ir_len = int(3.2 * sr)
    tir = np.arange(ir_len) / sr
    wet = []
    nfft = 1 << int(np.ceil(np.log2(n + ir_len)))
    for dry, seed in ((L, 1), (R, 2)):
        ir = np.random.default_rng(seed).normal(0, 1, ir_len) * np.exp(-tir * 1.9)
        ir = np.convolve(ir, np.ones(10) / 10, "same")
        ir /= np.sqrt(np.sum(ir ** 2)) * 1.6
        w = np.fft.irfft(np.fft.rfft(dry, nfft) * np.fft.rfft(ir, nfft), nfft)[:n]
        wet.append(w)
    L = L * 0.62 + wet[0] * 0.9
    R = R * 0.62 + wet[1] * 0.9
    L *= master
    R *= master
    peak = max(np.max(np.abs(L)), np.max(np.abs(R)), 1e-9)
    st = np.stack([L, R], 1) / peak * 0.86
    with wave.open(path, "wb") as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes((st * 32767).astype("<i2").tobytes())


# ----------------------------------------------------------------- main ---
def find_ffmpeg():
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        sys.exit("ffmpeg not found. Run: pip install imageio-ffmpeg   (or install ffmpeg)")


def pick(arg, name):
    for c in (arg, os.path.join(HERE, "assets", name + ".jpeg"), os.path.join(HERE, "assets", name + ".jpg"),
              os.path.join(HERE, "assets", name + ".png")):
        if c and os.path.exists(c):
            return c
    sys.exit(f"Missing assets/{name}.jpeg")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="ik_onkar_guru_nanak_jayanti.mp4")
    ap.add_argument("--fast", action="store_true", help="540x960 preview render")
    ap.add_argument("--still", type=float, help="save a single PNG at this time (seconds)")
    ap.add_argument("--audio-only", action="store_true")
    ap.add_argument("--guru")
    ap.add_argument("--village")
    a = ap.parse_args()

    wav = os.path.join(HERE, "_score.wav")
    if a.audio_only:
        synth_audio(wav)
        print("wrote", wav)
        return
    film = Film(pick(a.guru, "guru"), pick(a.village, "village"))
    if a.still is not None:
        Image.fromarray(film.render(a.still)).save(f"still_{a.still:05.1f}.png")
        print("saved still")
        return

    print("Composing score..."); synth_audio(wav)
    ow, oh = (W // 2, H // 2) if a.fast else (W, H)
    cmd = [find_ffmpeg(), "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{ow}x{oh}",
           "-r", str(FPS), "-i", "-", "-i", wav, "-c:v", "libx264", "-preset", "medium", "-crf", "16",
           "-pix_fmt", "yuv420p", "-profile:v", "high", "-movflags", "+faststart", "-c:a", "aac", "-b:a", "192k",
           "-shortest", a.out]
    pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    total = int(DUR * FPS)
    t0 = time.time()
    for i in range(total):
        fr = film.render(i / FPS)
        if a.fast:
            fr = np.asarray(Image.fromarray(fr).resize((ow, oh), Image.BILINEAR))
        pr.stdin.write(fr.tobytes())
        if i % 30 == 0:
            el = time.time() - t0
            eta = el / (i + 1) * (total - i - 1)
            print(f"\r frame {i}/{total}  ({100 * i / total:4.1f}%)  ETA {eta / 60:4.1f} min", end="", flush=True)
    pr.stdin.close(); pr.wait()
    print(f"\nDone -> {a.out}")


if __name__ == "__main__":
    main()
